<?php
if(!defined('jk')) die('Access Not Allowed !');
global $Cp;
$Cp->addSidebar([
    "title"=>__("Aparat"),
    "link"=>JK_DOMAIN_LANG."cp/aparat/index",
    "name"=>"aparat",
    "icon"=>"fa fa-chart-bar",
]);

$Cp->addSidebar([
    "title"=>__("Aparat"),
    "link"=>JK_DOMAIN_LANG."cp/aparat/index",
    "name"=>"aparat",
    "icon"=>"fa fa-chart-bar",
    "sub"=>[
        [
            "title"=>__("Last Vidio"),
            "link"=>"last",
            "name"=>"Last Vidio",
            "icon"=>"fa fa-list",
        ],
        [
            "title"=>__("Category"),
            "link"=>"cat",
            "name"=>"cat viedio",
            "icon"=>"fa fa-plus",
        ],[
            "title"=>__("pages list"),
            "link"=>"pages",
            "name"=>"pages",
            "icon"=>"fa fa-list",
        ]
    ],
]);