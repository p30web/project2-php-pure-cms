<?php

if(!defined('jk')) die('Access Not Allowed !');
global $ACL;
if (!$ACL->hasPermission('apara_page')) {
    error403();
    die;
}

global $View;
global $Users;
global $Cp;
$Cp->setSidebarActive('blog/pages');

$View->head();



