<?php
define("BASE", "http://localhost/");