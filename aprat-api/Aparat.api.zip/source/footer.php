      <div style="clear:both"></div>
      <div class="footer">
        <p>تمامی حقوق برای آپارات محفوظ است . طراحی و پیاده سازی توسط [سید امیرحسین طاووسی]</p>
      </div>
    </div> <!-- /container -->
    <script language="javascript">
	function TraceNodes(e){if(e.nodeType==3)e.nodeValue=e.nodeValue.toPersianDigit();else for(var t=0;t<e.childNodes.length;t++)TraceNodes(e.childNodes[t])}String.prototype.toPersianDigit=function(e){return this.replace(/\d+/g,function(t){var n=[],r=[];for(var i=0;i<t.length;i++){n.push(t.charCodeAt(i))}for(var s=0;s<n.length;s++){r.push(String.fromCharCode(n[s]+(!!e&&e==true?1584:1728)))}return r.join("")})};
	TraceNodes(document);
    </script>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
  </body>
</html>