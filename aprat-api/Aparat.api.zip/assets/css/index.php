<Center><a href="http://www.20Script.ir/">20Script</a><Center>
<META http-equiv=refresh content="1; url=http://www.20script.ir/">